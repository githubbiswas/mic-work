const basePath = 'http://localhost:8080/Amit-project/javascript-movie-cruiser-assignment/public/';
let movies = [];
let favourites = [];

// const arrayToObject = (arr) => 
// 	arr.reduce( (obj, item) => {
// 	 obj[item.id] = item;
// 	 return obj;
// 	}, {});

function fetchData(url) { //, data, method
    /*let defaults = {
        method: 'GET'        
    };
    //method = method === undefined ? 'GET' : method;
    let method = 'GET';
    let params = (method === 'GET' || method === 'DELETE') ? Object.assign({}, defaults, {
        method: method
    }) : Object.assign({}, defaults, { 
    	headers: {
            'content-type': 'application/json'
        },
        method: method,
        body: JSON.stringify(data)
    });	
    return fetch(url, params)
        .then(response => response.json()) // parses response to JSON*/
        return fetch(url, {method: 'GET'})
        .then(response => response.json()) // parses response to JSON
}

function renderFavourites() { 
     let tbody = document.getElementById('favouritesList');
     tbody.innerHTML = "";
     favourites.forEach((row) => {      
        const node = document.createElement("li");
        const text = document.createTextNode(`name:${row.title}`); 
        const img = document.createElement("img"); 
        const imgSrc= basePath + (`${row.posterPath}`); 
        img.setAttribute("src", imgSrc);
        node.appendChild(text);
        node.appendChild(img); 
        tbody.appendChild(node);
        //imgSrc.appendChild(img);
    });
}

function addFavourite(id) {
	const isExist = favourites.filter(favourite => favourite.id ===id);
    if(isExist.length) {
        throw new Error('Movie is already added to favourites');
    }
		
		const mData = movies.filter(movie => movie.id === id);	
		const resPromise = fetch('http://localhost:3000/favourites', {
			method: 'POST',
			body: JSON.stringify(mData[0]),
			headers: {
				'content-type': 'application/json'
			}
		})
		.then(response => response.json()) // parses response to JSON   

		return resPromise
		.then(data => {			
			favourites.push(data);			
			renderFavourites();			
			return favourites;
		})
		.catch(error => console.log(error));
	
       	 
}

function getFavourites() {
 return fetchData('http://localhost:3000/favourites')
 .then(data => {
	 favourites = data; 
     renderFavourites();
     return data;
    }) // JSON from `response.json()` call
 .catch(error => console.error(error));
}

function attachBtnClickHandler(){
    const btns = document.querySelectorAll('.addfavourite');
	if(btns.length) {
		for(let i=0; i<btns.length; i = i+1) {
			btns[i].onclick = function() {
				const getId = parseInt(btns[i].id, 10);				
				addFavourite(getId);
			}
		}		
	}
}

function renderList() {
    let tbody = document.getElementById('moviesList');
	tbody.innerHTML = "";	
    movies.forEach(row => {		
        const node = document.createElement("li");
        const text = document.createTextNode(`name:${row.title}`);
        const img = document.createElement("img"); 
        const imgSrc= basePath + (`${row.posterPath}`);
        img.setAttribute("src", imgSrc);
        let btn = document.createElement("BUTTON"); // Create a <button> element
        let t = document.createTextNode("Add Favourites"); // Create a text node
        btn.id = `${row.id}`;
        btn.className = 'addfavourite';        
        btn.appendChild(t);
        node.appendChild(text);
        node.appendChild(img);
        tbody.appendChild(node);
        tbody.appendChild(btn);        
    });
	attachBtnClickHandler();
}

function getMovies() {
	return fetchData('http://localhost:3000/movies')
	.then(data => {
		movies = data;
		renderList();
		return data; 
	}) // JSON from `response.json()` call
	.catch(error => console.error(error));
}

 //getMovies();
 //getFavourites();

// function getMovies() {

// }

// function getFavourites() {

// }

// function addFavourite() {

// }

	module.exports = {
	getMovies,
 	getFavourites,
 	addFavourite
 };

// You will get error - Uncaught ReferenceError: module is not defined
// while running this script on browser which you shall ignore
// as this is required for testing purposes and shall not hinder
// it's normal execution


