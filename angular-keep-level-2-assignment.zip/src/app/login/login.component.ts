
import { Component } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { Register } from './../register';
import { AuthenticationService} from '../services/authentication.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent {
    username = new FormControl('', [Validators.required]);
    password = new FormControl('', [Validators.required]);

constructor (private _authservices: AuthenticationService) { }

getUsernameErrorMessage() {
  return this.username.hasError('required') ? 'You must enter a value' : '';
}
getPasswordErrorMessage() {
  return this.password.hasError('required') ? 'Not a valid Email' : '';
}
    loginSubmit() {
      const user: Register = new Register(this.username.value, this.password.value);
      return this._authservices.authenticateUser(user).subscribe(
      res => {
      console.log(res['token']);
      }
    );
  }
}
