

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormControl, Validators } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { Note } from './note';
import { HttpClientModule } from '@angular/common/http';
import { AuthenticationService } from './services/authentication.service';
// import { NotesServices } from './services/notes.service';

import { MatToolbarModule } from '@angular/material/toolbar';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';

import {MatInputModule} from '@angular/material';
import {MatButtonModule} from '@angular/material';
import { DashboardComponent } from './dashboard/dashboard.component';
import { Router } from '@angular/router/src/router';


const appRouters: Routes = [
  {
    path: 'Dashboard',
    component: DashboardComponent
  },
  {
    path: 'Login',
    component: LoginComponent
  }
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatToolbarModule,
    MatInputModule,
    MatButtonModule,
    RouterModule.forRoot(appRouters)
    ],
  providers: [ AuthenticationService],
  bootstrap: [AppComponent]
})


export class AppModule { }
