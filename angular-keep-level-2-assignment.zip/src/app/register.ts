export class Register {
    username: string;
    password: string;
    constructor(u, p) {
        this.username = u;
        this.password = p;
    }
}
