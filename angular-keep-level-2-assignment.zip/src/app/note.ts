export class Note {
	
}
