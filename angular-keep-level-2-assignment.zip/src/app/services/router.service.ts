// import { Injectable } from '@angular/core';

// @Injectable()
// export class RouterService {

//   constructor() { }

//   routeToDashboard() {

//   }

//   routeToLogin() {
  	
//   }
// }
