// Write a program to display one result card of 100 students
// with their name and percentage
// Out of 100 students, 50 has subjects - Grammer and Accounts
// and other 50 has subjects -  Grammer and Physics

// Hint : You need to calculate percentage of 100 students having different set of subjects.
//        You can assume their scores on their respective subjects.


// Write your code here 


let genTable = ()=>{
    let students=[];
    document.write("<div></div>");
    let body=document.getElementsByTagName("div")[0];
    let Tbl= document.createElement("table");
    let props=[];
    for(var i=1;i<=100;i++){
        let data= {'name':'','grammer':'','accounts':'','physics':'','percentage':''};
        var row=document.createElement("tr");

        if(Math.round(Math.random() * 10)%2){
            data.name = 'Cand_' + i;
            data.grammer = Math.round(Math.random() * 100);
            data.accounts = Math.round(Math.random() * 100);
            data.physics = '-';
            data.percentage = ((data.grammer+data.accounts)/2) + '%';
        } else {
            data.name = 'Cand_' + i;
            data.grammer = Math.round(Math.random() * 100);
            data.accounts = '-';
            data.physics = Math.round(Math.random() * 100);
            data.percentage = ((data.grammer+data.physics)/2) + '%';
        }
        props.push({name: 'Cand_' + i});
        //students.push(data);
        if(!props.length){
            for(property in data){
                props.push(property);
            }
        }
        for(var j=0;j<5;j++){
            var td=document.createElement("td");
            var key = props[j];
            td.innerHTML = data[key];
            td.style.border='1px solid #000';
            row.appendChild(td);
        }
        Tbl.appendChild(row);
    }
    body.appendChild(Tbl);
}


genTable();