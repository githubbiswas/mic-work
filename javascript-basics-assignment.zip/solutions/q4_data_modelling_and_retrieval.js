// Create a list of fruits with their properties (name, color, pricePerKg)
// and convert it into a format so that for a given fruit name
// retrieval of its color and pricePerKg value is fast


// Write your code here

const arr = [
    {
        "name": "Apples",
        "color": "Red",
        "price": 40
    },
    {
        "name": "Oranges",
        "color": "Orange",
        "price": 40
    },
    {
        "name": "Bananas",
        "color": "yollow",
        "price": 40
    },
    {
        "name": "Peaches",
        "color": "Red",
        "price": 40
    },
    {
        "name": "Grapes",
        "color": "Green",
        "price": 40
    },
    {
        "name": "Lemons",
        "color": "yallow",
        "price": 40
    }
];

const fruitlist = () => {
let tbt='<table border="1">';    
    for(let i=0;i<arr.length;i=i+1) {
        tbt+='<tr align="center">';
        tbt+='<td >' + arr[i].name + '</td>';
        tbt+='<td style="border:1px solid #000">' + arr[i].color + '</td>';
        tbt+='<td style="border:1px solid #000">' + arr[i].price + '</td>';
        tbt+='</tr>';
    }
    tbt+='</table></br>';
    document.write(tbt);
}
const test = () => {
    let value=document.getElementById("input").value;
    let result = arr.find(item=>item.name===value);
    document.write('<p>Color:'+result.color+'</p><p>Price:'+result.price+'</p>');
}

fruitlist();
document.write('<input id="input" type="text"> <button id="submit">click</button>');
document.getElementById("submit").onclick=test;
