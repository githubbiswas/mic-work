/* Write a program to build a `Pyramid of stars` of given height */

let k,j,i;
const buildPyramid = (count) => {
let str='';
    for(i=1;i<=count;i=i+1){
        for(k=1;k<=(count-i+1);k=k+1){
            str+=' ';
        }
        for(j=1;j<=i;j=j+1){
          str+='* ';
        }
        str+=' \n';
    }
    return str;
};

/* For example,
INPUT - buildPyramid(6)
OUTPUT -
     *
    * *
   * * *
  * * * *
 * * * * *
* * * * * *

*/

module.exports = buildPyramid;
