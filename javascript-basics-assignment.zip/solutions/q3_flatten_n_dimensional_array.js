/* Write a Program to Flatten a given n-dimensional array */
//var arr = [1, [2, 3], [[4, 5], [6, 7]], [[[8, 9], 10]]];
const flatten = (arr) => {
	// Write your code here
	if(Array.isArray(arr)){
		return arr.reduce(function(flat,toFlatten){
			return flat.concat(Array.isArray(toFlatten) ? flatten(toFlatten):toFlatten);
		},[]);
	}
		return null;
};


/* For example,
INPUT - flatten([1, [2, 3], [[4], [5]])
OUTPUT - [ 1, 2, 3, 4, 5 ]

*/

module.exports = flatten;
