export class Note {
	title: string;
	text: string;
	constructor() {
		this.title = '';
		this.text = '';
	}
}
