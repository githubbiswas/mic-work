import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Note } from './note';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class NotesService {

	constructor(private http: HttpClient) {
	}

	getNotes(): Observable<Array<Note>> {
		return this.http.get<Array<Note>>('http://localhost:3000/notes')
			.catch((err:any) => {				
				return Observable.throw(err);
			});
	}

	addNote(note: Note): Observable<Note> {
		return this.http.post<Note>('http://localhost:3000/notes', note)
		.catch((err:any) => {
			return Observable.throw(err);
		});
	}

}
