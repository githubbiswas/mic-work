import { Component, OnInit } from '@angular/core';
import { Note } from './note';
import { NotesService } from './notes.service';
import { HeaderComponent } from './header/header.component';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css'],
	providers: [NotesService]
})

export class AppComponent implements OnInit {
	errMessage: string;
	note: Note = new Note();
	notes: Array<Note> = [];

	constructor(private notesService: NotesService) {
	}

	ngOnInit() {
		this.notesService.getNotes().subscribe(
			data => this.notes = data,
			err => {
				this.errMessage = err.message;				
			}
		);
	}

	takeNote() {

		if('' === this.note.title || '' === this.note.text) {
			this.errMessage = 'Title and Text both are required fields';
			return !0;
		}

		this.notesService.addNote(this.note).subscribe(
			data => {
				this.notes.push(data);
			},
			err => {
				this.errMessage = err.message;
			},
			() => {
				this.note.title = '';
				this.note.text = '';
			}
		);
	}

}
