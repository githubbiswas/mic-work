import { Component, OnInit, Input } from '@angular/core';
import { Note } from '../note';
import { NotesService } from '../notes.service';
import { Output } from '../../../node_modules old/@angular/core/src/metadata/directives';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.css'],
  providers: [NotesService]
})
export class NotesComponent implements OnInit {
  note: Note = new Note();
  notes: Array<Note> = [];
  @Input() errMessage: string;

  constructor(private notesService: NotesService) { }

  ngOnInit() {
    this.notesService.getNotes().subscribe(
      data => this.notes = data,
      err => {
        this.errMessage = err;
        console.log('err');
      }
    );
  }
  takeNote() {
      this.notes.push(this.note);
      this.notesService.addNote(this.note).subscribe(
        data => { },
        err => {
          const index: number =
          this.notes.findIndex(note => note.title === this.note.title);
          this.notes.splice(index, 1);
        }
      );
      this.note = new Note();
      console.log(this.note.title + '' + this.note.text);
  }
}

// {
//   "notes": [
//     {
//       "id": 1,
//       "title": "Read Angular 5 blog",
//       "text": "Shall do at 6 pm"
//     },
//     {
//       "title": "aa",
//       "text": "ss",
//       "id": 2
//     },
//     {
//       "title": "hhhh",
//       "text": "rrrrr",
//       "id": 3
//     },
//     {
//       "title": "",
//       "text": "",
//       "id": 4
//     }
//   ]
// }