

1. First fork this repository into my account
2.Clone the repository to my workspace using the command: ```git clone repository-url>````
3. Install dependencies using yarn command: ```npm install```
4. Start http-server to preview the web page: ```http-server -c-1``` # Problem Statement

1. Build a basic HTML structure
2. Define the dependencies like bootstrap, jquery, external css.
3. Check with browser with localhost.
4. Used google font for font support.
5. Checked with developer tool for responsiveness. 