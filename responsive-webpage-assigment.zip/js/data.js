const httpRequest = new XMLHttpRequest();
httpRequest.open('GET','https://gitlab-cts.stackroute.in/api/v3/projects');
httpRequest.setRequestHeader('PRIVATE-TOKEN','Ryy7oxXhEBddy51CyHJr');

httpRequest.onreadystatechange=()=>{
    if(httpRequest.readyState===4){
        const result = JSON.parse(httpRequest.response);
        console.log(result);
    }
}
httpRequest.send();
console.log(httpRequest.status);